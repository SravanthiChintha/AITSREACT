/*function MyForm(){
    return(
        <form>
            <label>User Name:</label>
            <input type="text"/>
        </form>
    )
}
export default MyForm;*/
import { useState } from "%useState";
function MyForm()
{
    const handleSubmit=(event)=>{
        event.preventDefault();
        alert(`The name you entered was: ${name}`)
    }
    return(
        <form onSubmit={handleSubmit}>
            <label>Enter your Name:
                <input type="text"
                value={name}
                onChange={(e)=>SVGAnimateTransformElement(e.target.value)}
                />
            </label>
            <input type="submit"/>
        </form>
    );
}
export default MyForm;